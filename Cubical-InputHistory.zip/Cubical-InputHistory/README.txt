Version: 1.0
Author: Cubical
Release Date 2/7/2025

This Mod displays an overlay UI that tracks and records your in game inputs. It also displays the time between new inputs in miliseconds, frames, both, or none, depending on the player's choice in the modmenu settings window. It finally shows whether or not the input displayed was during the time a player was acitonable or not; if red background, then the player was actionable during that time, if green, then the player was not actionable.